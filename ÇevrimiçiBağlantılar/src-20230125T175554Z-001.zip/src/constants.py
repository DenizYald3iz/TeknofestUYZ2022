# DISCLAIMER TO CONTEST TEAMS :  DO NOT MAKE CHANGES IN THIS FILE.
classes = {
    "Tasit": 0,
    "Insan": 1,
    "UAP": 2,
    "UAI": 3,
}
landing_statuses = {
    "Inilebilir": "1",
    "Inilemez": "0",
    "Inis Alani Degil": "-1"
}
