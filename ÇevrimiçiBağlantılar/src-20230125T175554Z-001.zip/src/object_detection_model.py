import logging
import time
import torch
import requests
import cv2
import algoritma
from src.constants import classes, landing_statuses
from src.detected_object import DetectedObject
import os

class ObjectDetectionModel:
    # Base class for team models

    def __init__(self, evaluation_server_url):
        logging.info('Created Object Detection Model')
        self.evaulation_server = evaluation_server_url
        self.model = torch.hub.load("ultralytics/yolov5", "custom", path = "best.pt", force_reload=True)
    
    
    @staticmethod
    def download_image(img_url, images_folder):
        t1 = time.perf_counter()
        img_bytes = requests.get(img_url).content
        image_name = img_url.split("/")[-1]  # frame_x.jpg
        imgs = os.listdir("_images")
        with open(images_folder + image_name, 'wb') as img_file:
            img_file.write(img_bytes)
            
        img = cv2.imread(images_folder + image_name, cv2.IMREAD_COLOR)
        t2 = time.perf_counter()
        logging.info(f'{img_url} - Download Finished in {t2 - t1} seconds to {images_folder + image_name}')
        return img

    def process(self, prediction,evaluation_server_url):
        # Yarışmacılar resim indirme, pre ve post process vb işlemlerini burada gerçekleştirebilir.
        # Download image (Example)
        img = self.download_image(evaluation_server_url + "media" + prediction.image_url, "./_images/")
        # Örnek: Burada OpenCV gibi bir tool ile preprocessing işlemi yapılabilir. (Tercihe Bağlı)
        # ...
        # Nesne tespiti modelinin bulunduğu fonksiyonun (self.detect() ) çağırılması burada olmalıdır.
        frame_results = self.detect(prediction, img)
        # Tahminler objesi FramePrediction sınıfında return olarak dönülmelidir.
        return frame_results

    def detect(self, prediction, img):
        # Modelinizle bu fonksiyon içerisinde tahmin yapınız.
        # results = self.model.evaluate(...) # Örnektir.
        results = self.model(img)
        table = results.pandas().xyxy[0]
        
        x_max = list(table["xmax"].values)
        x_min = list(table["xmin"].values)
        y_max = list(table["ymax"].values)
        y_min = list(table["ymin"].values)
        all_class = list(table["class"].values)
        ids = list(table.index)
        final_result = algoritma.result(all_class, x_max, x_min, y_max, y_min, ids) 
        for i in range(len(x_max)):
            for obj in final_result:
                if obj[0] == i:
                    if obj[1] == 1:
                        con = 'Inilebilir'
                    elif obj[1] == 0:
                        con = "Inilemez"
                    else:
                        con = "Inis Alani Degil"
            if all_class[i] == 0:
                nesne = "Tasit"
            elif all_class[i] == 1:
                nesne = "Insan"
            elif all_class[i] == 2:
                nesne = "UAP"
            elif all_class[i] == 3:
                nesne = "UAI"
            
            cls = classes[nesne] 
            landing_status = landing_statuses[con]  
            top_left_x = x_min[i]  
            top_left_y = y_max[i]  
            bottom_right_x = x_max[i]  
            bottom_right_y = y_min[i]  

            # Modelin tespit ettiği herbir nesne için bir DetectedObject sınıfına ait nesne oluşturularak
            # tahmin modelinin sonuçları parametre olarak verilmelidir.
            d_obj = DetectedObject(cls,
                                   landing_status,
                                   top_left_x,
                                   top_left_y,
                                   bottom_right_x,
                                   bottom_right_y)
            # Modelin tahmin ettiği her nesne prediction nesnesi içerisinde bulunan detected_objects listesine eklenmelidir.
            prediction.add_detected_object(d_obj)
        algoritma.final = []
        algoritma.inis_nokta = []
        algoritma.objeler = []

        return prediction
